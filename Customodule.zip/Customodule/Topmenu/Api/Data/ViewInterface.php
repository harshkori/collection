<?php
namespace Customodule\Topmenu\Api\Data;

interface ViewInterface
{
    /**#@+
     * Constants for keys of data array. Identical to the name of the getter in snake case
     */
    const ID          =     'id';
    const P_NM        =     'p_nm';
    const P_PRICE     =     'p_price';
    const SKU         =     'sku';
    /**#@-*/


    /**
     * Get Title
     *
     * @return string|null
     
     */
    public function getName();

    /**
     * Get Content
     *
     * @return string|null
     */
    public function getPrice();

    /**
     * Get Created At
     *
     * @return string|null
     */
    public function getSku();

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Set Title
     *
     * @param string $title
     * @return $this
     */
    public function setName($title);

    /**
     * Set Content
     *
     * @param string $content
     * @return $this
     */
    public function setPrice($content);

    /**
     * Set Crated At
     *
     * @param int $createdAt
     * @return $this
     */
    public function setSku($createdAt);

    /**
     * Set ID
     *
     * @param int $id
     * @return $this
     */
    public function setId($id);
}
