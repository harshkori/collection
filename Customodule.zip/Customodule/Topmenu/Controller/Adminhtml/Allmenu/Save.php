<?php
namespace Customodule\Topmenu\Controller\Adminhtml\Allmenu;

class Save extends \Magento\Backend\App\Action
{

    const ADMIN_RESOURCE = 'Index';

    protected $resultPageFactory;
    protected $EventFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();


        // if($data) {
        //     try {

        //         if (!$data['store_ids']) {                    
        //             $data['store_ids'] = 0;                    
        //         }
        //         if (is_array($data['store_ids'])) {
        //             $data['store_ids'] = implode(',', $data['store_ids']);
        //         }
              
        //         $id = $data['entity_id'];

        //         $event = $this->EventFactory->create()->load($id);

        //         $data = array_filter($data, function($value) {return $value !== ''; });

        //         $event->setData($data);
        //         $event->save();
        //         $this->messageManager->addSuccess(__('Successfully saved the item.'));
        //         $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
        //         //return $resultRedirect->setPath('*/*/');
        //         return $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        //     }
        //     catch(\Exception $d)
        //     {
        //         $this->messageManager->addError($e->getMessage());
        //         $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData($data);
        //         return $resultRedirect->setPath('*/*/edit', ['id' => $event->getId()]);
        //     }
        // }

         return $resultRedirect->setPath('purchased/index/index');
    }
}
