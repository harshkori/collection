<?php
namespace Customodule\Topmenu\Controller\Adminhtml\Allmenu;

class Index extends \Magento\Framework\App\Action\Action
{

protected $resultFactory;

public function __construct(
    \Magento\Framework\Controller\ResultFactory $resultFactory,
    \Magento\Framework\App\Action\Context $context
)
{
   $this->resultFactory = $resultFactory;

   return parent::__construct($context);
}

public function execute()
{
    exit("hii");
    $redirect = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_REDIRECT);
    $redirect->getUrl('/redirect/to/destination');

    return $redirect;
}

}