<?php

namespace Customodule\Topmenu\Block;

use \Magento\Framework\View\Element\Template;
use \Magento\Framework\View\Element\Template\Context;
use \Customodule\Topmenu\Model\ResourceModel\View\Collection as ViewCollection;
use \Customodule\Topmenu\Model\ResourceModel\View\CollectionFactory as ViewCollectionFactory;
use \Customodule\Topmenu\Model\View;

class Display extends Template
{
    /**
     * CollectionFactory
     * @var null|CollectionFactory
     */
    protected $_viewCollectionFactory = null;

    /**
     * Constructor
     *
     * @param Context $context
     * @param ViewCollectionFactory $viewCollectionFactory
     * @param array $data
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Data\Form\FormKey $formKey,
        ViewCollectionFactory $viewCollectionFactory,
        array $data = []
    ) {
        $this->_viewCollectionFactory  = $viewCollectionFactory;
        $this->formKey = $formKey;
        parent::__construct($context, $data); 

    }

    /**
     * @return Post[]
     */
    public function getCollection()
    {
        /** @var ViewCollection $viewCollection */
        $viewCollection = $this->_viewCollectionFactory ->create();
        $viewCollection->addFieldToSelect('*')->load();
        return $viewCollection->getItems();
    }

    /**
     * For a given post, returns its url
     * @param Post $post
     * @return string
     */
    public function getArticleUrl(View $view)
    {
        return '/mymodule/view/id/' . $view->getId();
    }
    
    public function getFormKey()
    {
         return $this->formKey->getFormKey();
    }
}