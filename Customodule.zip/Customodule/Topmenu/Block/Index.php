<?php
namespace Customodule\Topmenu\Block;
class Index extends \Magento\Framework\View\Element\Template
{

}