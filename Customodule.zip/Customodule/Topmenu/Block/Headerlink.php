<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade to the newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Tutorial
 * @copyright Copyright (C) 2021 Magezon (https://www.magezon.com)
 */

namespace Customodule\Topmenu\Block;

use Magento\Framework\View\Element\Template;

class Headerlink extends Template
{
    protected $_template = 'Customodule_Topmenu::newheaderlink.phtml';

    protected function _toHtml()
    {
        $this->setlinkname("OUTDOOR FURNITURE");
        $this->setlinkname1("LIVING ROOM");
        $this->setlinkname2("DINING & KITCHEN ");
        $this->setlinkname3("HOMEWARES");
        $this->setlinkname4("SALE");

        return parent::_toHtml();
    }

    
}